# [Bootcamp Frontend T G14](https://elliotxleo.github.io/bootcamp-frontend-t-g14/) | [<img src="https://i.postimg.cc/dtPYcvbM/youtube.png" alt="YouTube" height="20px"/>](https://www.youtube.com/channel/UCE9whBrtYnLWrpzwk6z_JUA) | [<img src="https://i.postimg.cc/5NBMxTJX/github.png" alt="GitHub" height="20px"/>](https://github.com/ElliotXLeo) | [<img src="https://i.postimg.cc/J7BLFtdc/linkedin.png" alt="Linkedin" height="20px"/>](https://www.linkedin.com/in/elliotgaramendi/) | [<img src="https://i.postimg.cc/sfJtqS4W/instagram.png" alt="Instagram" height="20px"/>](https://www.instagram.com/elliotgaramendi/) | [<img src="https://i.postimg.cc/7YHyZXZX/facebook.png" alt="Facebook" height="20px"/>](https://www.facebook.com/elliotgaramendi) | [<img src="https://i.postimg.cc/65TVxg9t/world-globe.png" alt="Portafolio Web" height="20px"/>](https://elliotxleo.github.io/portafolio-web-elgs/)

[![Bootcamp Frontend T G14](https://i.postimg.cc/kg2k7v3P/lp-b2-w-4b-elgs.png)](https://elliotxleo.github.io/bootcamp-frontend-t-g14/)

## 📜 Resumen 📜
El mejor lugar donde puedes aprender sobre desarrollo web. Asimismo, con Base 2 by Web 4B puedes hacer realidad ese sueño que tienes en mente. ¡Cambia tu vida!

## 💻 Instalación 💻
- Ubicarse en la carpeta que contendrá el proyecto
- Abrir terminal de comandos
  - git clone https://github.com/ElliotXLeo/bootcamp-frontend-t-g14.git
  - cd bootcamp-frontend-t-g14
  - Levantar la web en un servidor y disfrutar

## 👨‍💻 Tecnologías Usadas 👨‍💻
<table>
  <thead>
    <tr>
      <th>HTML</th>
      <th>CSS</th>
      <th>JavaScript</th>
      <th>Bootstrap</th>
      <th>Sass</th>
      <th>React</th>
      <th>React Router</th>
      <th>Redux</th>
      <th>Axios</th>
      <th>Firebase</th>
      <th>Jest</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>
        <img src="https://i.postimg.cc/rF6WrLjr/html.png" width="100%" />
      </td>
      <td>
        <img src="https://i.postimg.cc/mgSDG9F2/css.png" width="100%" />
      </td>
      <td>
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/99/Unofficial_JavaScript_logo_2.svg/1200px-Unofficial_JavaScript_logo_2.svg.png" width="100%" />
      </td>
      <td>
        <img
          src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b2/Bootstrap_logo.svg/1200px-Bootstrap_logo.svg.png"
          width="100%" />
      </td>
      <td>
        <img src="https://miro.medium.com/max/512/1*9U1toerFxB8aiFRreLxEUQ.png" width="100%" />
      </td>
      <td>
        <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/React-icon.svg/1280px-React-icon.svg.png"
          width="100%" />
      </td>
      <td>
        <img src="https://iconape.com/wp-content/files/sm/371377/svg/371377.svg" width="100%" />
      </td>
      <td>
        <img src="https://upload.wikimedia.org/wikipedia/commons/4/49/Redux.png" width="100%" />
      </td>
      <td>
        <img
          src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/35/Axios_logo_%282017%29.svg/1200px-Axios_logo_%282017%29.svg.png"
          width="100%" />
      </td>
      <td>
        <img
          src="https://www.gstatic.com/devrel-devsite/prod/vb4b5f40392bd9ba34d31c8578d2b4bd0a5bd852eabd9554190f5a24f31b598a8/firebase/images/touchicon-180.png"
          width="100%" />
      </td>
      <td>
        <img
          src="https://nx.dev/documentation/shared/jest-logo.png"
          width="100%" />
      </td>
    </tr>
  </tbody>
</table>

## 🤗 Redes sociales 🤗
- 🐭 YouTube: https://www.youtube.com/channel/UCE9whBrtYnLWrpzwk6z_JUA 🐭
- 🐭 GitHub: https://github.com/ElliotXLeo 🐭
- 🐭 LinkedIn: https://www.linkedin.com/in/elliotgaramendi/ 🐭
- 🐭 Instagram: https://www.instagram.com/elliotgaramendi/ 🐭
- 🐭 Facebook: https://www.facebook.com/elliotgaramendi 🐭
- 🐭 Portafolio Web: https://elliotxleo.github.io/portafolio-web-elgs/ 🐭