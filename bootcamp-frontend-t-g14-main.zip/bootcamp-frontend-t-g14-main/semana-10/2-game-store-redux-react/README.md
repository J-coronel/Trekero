# [Game Store Redux React](https://game-store-redux-react.netlify.app) | [<img src="https://i.postimg.cc/J7BLFtdc/linkedin.png" alt="LinkedIn" class="footer-nav__link-image" height="20px" />](https://www.linkedin.com/in/elliotgaramendi/)  | [<img src="https://i.postimg.cc/sfJtqS4W/instagram.png" alt="Instagram" class="footer-nav__link-image" height="20px" />](https://www.instagram.com/elliotgaramendi/)  | [<img src="https://i.postimg.cc/7YHyZXZX/facebook.png" alt="Facebook" class="footer-nav__link-image" height="20px" />](https://www.facebook.com/elliotgaramendi)  | [<img src="https://i.postimg.cc/5NBMxTJX/github.png" alt="GitHub" class="footer-nav__link-image" height="20px" />](https://github.com/ElliotXLeo)  | [<img src="https://i.postimg.cc/dtPYcvbM/youtube.png" alt="YouTube" class="footer-nav__link-image" height="20px" />](https://www.youtube.com/channel/UCE9whBrtYnLWrpzwk6z_JUA)  | [<img src="https://i.postimg.cc/65TVxg9t/world-globe.png" alt="Página Personal" class="footer-nav__link-image" height="20px" />](https://nextjs-react-portafolio-fc.vercel.app)

[![Game Store Redux React](https://i.postimg.cc/QMJNYL6b/game-store-redux-react.png)](https://game-store-redux-react.netlify.app)

Aplicación de una tienda de videojuegos que te permite comprar y retornar el juego Pokémon Rojo, asimismo puedes buscar un Pokémon y obtener sus datos consumiendo un API.

## 💻 Instalación 💻
- Ubicarse en la carpeta que contendrá el proyecto
- Abrir terminal de comandos
  - git clone https://github.com/ElliotXLeo/game-store-redux-react
  - cd game-store-redux-react
  - npm install
  - npm start
    - Levanta un servidor con la aplicación
  - npm run build
    - Genera un paquete para el despliegue en producción

## 👨‍💻 Tecnologías Usadas 👨‍💻
<table>
    <thead>
      <tr>
        <th>React</th>
        <th>HTML</th>
        <th>CSS</th>
        <th>JavaScript</th>
        <th>Redux</th>
        <th>Axios</th>
        <th>Bootstrap</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>
          <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a7/React-icon.svg/1280px-React-icon.svg.png"
            width="100%" />
        </td>
        <td>
          <img src="https://i.postimg.cc/rF6WrLjr/html.png" alt="LinkedIn" class="footer-nav__link-image"
            width="100%" />
        </td>
        <td>
          <img src="https://i.postimg.cc/mgSDG9F2/css.png" alt="LinkedIn" class="footer-nav__link-image"
            width="100%" />
        </td>
        <td>
          <img
            src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/99/Unofficial_JavaScript_logo_2.svg/1200px-Unofficial_JavaScript_logo_2.svg.png"
            width="100%" />
        </td>
        <td>
          <img src="https://upload.wikimedia.org/wikipedia/commons/4/49/Redux.png" width="100%" />
        </td>
        <td>
          <img
            src="https://upload.wikimedia.org/wikipedia/commons/thumb/3/35/Axios_logo_%282017%29.svg/1200px-Axios_logo_%282017%29.svg.png"
            width="100%" />
        </td>
        <td>
          <img
            src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b2/Bootstrap_logo.svg/1200px-Bootstrap_logo.svg.png"
            width="100%" />
        </td>
      </tr>
    </tbody>
  </table>



## 🤗 Redes Sociales 🤗
- 🐭 LinkedIn: https://www.linkedin.com/in/elliotgaramendi/ 🐭
- 🐭 Instagram: https://www.instagram.com/elliotgaramendi/ 🐭
- 🐭 Facebook: https://www.facebook.com/elliotgaramendi/ 🐭
- 🐭 GitHub: https://github.com/ElliotXLeo/ 🐭
- 🐭 YouTube: https://www.youtube.com/channel/UCE9whBrtYnLWrpzwk6z_JUA/ 🐭
- 🐭 Web Personal: https://nextjs-react-portafolio-fc.vercel.app 🐭