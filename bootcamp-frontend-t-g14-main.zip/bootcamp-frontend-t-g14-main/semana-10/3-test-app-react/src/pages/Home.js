const Home = () => {
  return (
    <>
      <h1>Home Title</h1>
      <p>paragraph</p>
    </>
  );
}

export default Home;