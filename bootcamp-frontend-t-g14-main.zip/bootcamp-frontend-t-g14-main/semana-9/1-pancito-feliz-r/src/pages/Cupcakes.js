import CardCupcakes from '../components/cards/CardCupcakes';
import '../styles/css/Cupcakes.css';

const Cupcakes = () => {
  return (
    <CardCupcakes
      title='🧁 Cupcakes 🧁'
      filter=''
    />
  );
}

export default Cupcakes;