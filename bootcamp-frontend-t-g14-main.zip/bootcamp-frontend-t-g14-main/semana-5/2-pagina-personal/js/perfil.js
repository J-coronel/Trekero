const perfil = [
  'Elliot Garamendi',
  'Elliot Garamendi Desarrollador de tus sueños',
  'Estudiante de Ingeniería de Software perteneciente a los primeros puestos. Apasionado del autoaprendizaje con el sueño de crecer en el Desarrollo Web Frontend con la biblioteca React. Asimismo, amo compartir los conocimientos adquiridos día a día mediante la docencia.',
  'https://1drv.ms/u/s!As5U-bd3F-a6gYsmbbG-Dybk88biRQ?e=Rifl4V',
  'https://i.postimg.cc/bvJLLgZd/perfil-elliotgaramendi.jpg',
  'https://www.linkedin.com/in/elliotgaramendi/'
];