const contactos = [
  {
    "id": 0,
    "name": "LinkedIn",
    "urlContact": "https://www.linkedin.com/in/elliotgaramendi/",
    "urlImage": "https://i.postimg.cc/J7BLFtdc/linkedin.png",
    "main": 1
  },
  {
    "id": 1,
    "name": "Instagram",
    "urlContact": "https://www.instagram.com/elliotgaramendi/",
    "urlImage": "https://i.postimg.cc/sfJtqS4W/instagram.png",
    "main": 1
  },
  {
    "id": 2,
    "name": "Facebook",
    "urlContact": "https://www.facebook.com/elliotgaramendi",
    "urlImage": "https://i.postimg.cc/7YHyZXZX/facebook.png",
    "main": 1
  },
  {
    "id": 3,
    "name": "GitHub",
    "urlContact": "https://github.com/ElliotXLeo",
    "urlImage": "https://i.postimg.cc/5NBMxTJX/github.png",
    "main": 1
  },
  {
    "id": 4,
    "name": "YouTube",
    "urlContact": "https://www.youtube.com/channel/UCE9whBrtYnLWrpzwk6z_JUA",
    "urlImage": "https://i.postimg.cc/dtPYcvbM/youtube.png",
    "main": 1
  },
  {
    "id": 5,
    "name": "Página Personal",
    "urlContact": "https://nextjs-react-portafolio-fc.vercel.app",
    "urlImage": "https://i.postimg.cc/65TVxg9t/world-globe.png",
    "main": 1
  }
];